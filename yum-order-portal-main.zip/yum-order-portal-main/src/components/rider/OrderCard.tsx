
import React from 'react';
import { MapPin, Receipt } from 'lucide-react';
import { Order } from '@/types/admin';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

interface OrderCardProps {
  order: Order;
  onUpdateStatus: (orderId: string, newStatus: 'pending' | 'completed' | 'packed') => void;
  onPrintBill: (order: Order) => void;
}

const OrderCard = ({ order, onUpdateStatus, onPrintBill }: OrderCardProps) => {
  return (
    <Card key={order.id} className="p-4 mb-4 border-l-4 border-l-primary">
      <div className="flex items-center gap-4">
        {order.image && (
          <img 
            src={order.image} 
            alt={order.name || 'Food item'} 
            className="w-20 h-20 object-cover rounded"
          />
        )}
        <div className="flex-1">
          <h3 className="font-semibold">{order.name}</h3>
          <p className="text-sm text-gray-500">
            Ordered by: {order.full_name}
          </p>
          <p className="text-sm text-gray-500">
            Phone: {order.mobile_number}
          </p>
          <p className="text-sm text-gray-500">
            Address: {order.address}
          </p>
          <div className="flex items-center mt-1">
            <MapPin className="h-3 w-3 mr-1 text-primary" />
            <p className="text-xs text-primary">
              {order.village || 'No city specified'}
            </p>
          </div>
        </div>
        <div className="text-right space-y-2">
          <p className="font-semibold">₹{order.price.toFixed(2)}</p>
          <div className="text-xs text-gray-500">
            {new Date(order.order_date).toLocaleString()}
          </div>
          <select
            className="px-2 py-1 rounded border"
            value={order.status}
            onChange={(e) => onUpdateStatus(order.id, e.target.value as 'pending' | 'completed' | 'packed')}
          >
            <option value="pending">Pending</option>
            <option value="packed">Packed</option>
            <option value="completed">Completed</option>
          </select>
          <Button 
            variant="outline" 
            size="sm" 
            className="mt-2 w-full flex items-center gap-1"
            onClick={() => onPrintBill(order)}
          >
            <Receipt className="h-3 w-3" />
            Print Bill
          </Button>
        </div>
      </div>
    </Card>
  );
};

export default OrderCard;
