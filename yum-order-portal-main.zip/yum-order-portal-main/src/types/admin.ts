
export interface Village {
  id: string;
  name: string;
  created_at: string;
}

export interface User {
  id: string;
  fullName: string;
  mobileNumber: string;
  address: string;
  orderCount: number;
  village?: string;
  lastSeen?: string;
  online?: boolean;
}

// Supabase User structure that matches the database schema
export interface SupabaseUser {
  id: string;
  phone_number: string;
  full_name: string;
  email: string;
  address: string;
  selected_city?: string | null;
  last_login?: string;
  created_at?: string;
}

export interface FoodItem {
  id: string;
  name: string;
  price: number;
  image: string;
  category: string;
  description?: string;
  village?: string;
  created_at?: string;
}

export interface Order {
  id: string;
  name: string;
  price: number;
  image: string;
  full_name: string;
  mobile_number: string;
  address: string;
  village?: string;
  order_date: string;
  status: 'pending' | 'completed' | 'packed';
  created_at?: string;
}
