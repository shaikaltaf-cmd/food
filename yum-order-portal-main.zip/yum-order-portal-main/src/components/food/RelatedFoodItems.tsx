
import React from 'react';
import { Card } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useQuery } from '@tanstack/react-query';
import { fetchFoodItems } from '@/services/foodService';

interface RelatedFoodItemsProps {
  category: string;
  currentItemId: string;
}

const RelatedFoodItems = ({ category, currentItemId }: RelatedFoodItemsProps) => {
  const { data: allFoodItems = [] } = useQuery({
    queryKey: ['foodItems', ''], // Empty string for no village filter
    queryFn: fetchFoodItems
  });

  const relatedItems = allFoodItems
    .filter(item => item.category === category && item.id !== currentItemId)
    .slice(0, 5);

  if (relatedItems.length === 0) {
    return null;
  }

  return (
    <div className="mt-6">
      <h3 className="text-lg font-semibold mb-3">Related Items</h3>
      <ScrollArea className="w-full whitespace-nowrap">
        <div className="flex space-x-4 pb-4">
          {relatedItems.map((item) => (
            <Card key={item.id} className="w-[200px] flex-shrink-0">
              <img
                src={item.image}
                alt={item.name}
                className="h-32 w-full object-cover"
              />
              <div className="p-3">
                <h4 className="font-medium truncate">{item.name}</h4>
                <p className="text-primary">₹{item.price.toFixed(2)}</p>
              </div>
            </Card>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
};

export default RelatedFoodItems;
