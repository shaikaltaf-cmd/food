
import React from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useNavigate } from 'react-router-dom';
import { supabase } from "@/integrations/supabase/client";
import { FoodItem } from '@/types/food';
import { Plus, Minus } from 'lucide-react';

interface OrderFormProps {
  foodItem: FoodItem;
  onClose: () => void;
}

const OrderForm = ({ foodItem, onClose }: OrderFormProps) => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [quantity, setQuantity] = React.useState(1);
  const [formData, setFormData] = React.useState({
    fullName: '',
    address: '',
    mobileNumber: ''
  });
  const [isSubmitting, setIsSubmitting] = React.useState(false);

  const handleQuantityChange = (increment: number) => {
    setQuantity(prev => Math.max(1, prev + increment));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const user = localStorage.getItem('user');
      if (!user) {
        toast({
          title: "Please Login",
          description: "You need to login before placing an order",
          variant: "destructive"
        });
        navigate('/login');
        return;
      }

      const orderData = {
        name: foodItem.name,
        price: foodItem.price * quantity,
        image: foodItem.image,
        quantity: quantity, // Now properly saving the quantity
        full_name: formData.fullName,
        mobile_number: formData.mobileNumber,
        address: formData.address,
        order_date: new Date().toISOString(),
        status: 'pending' as const
      };

      const { data, error } = await supabase
        .from('orders')
        .insert([orderData])
        .select()
        .single();

      if (error) {
        throw error;
      }

      toast({
        title: "Order Placed Successfully",
        description: `Your order for ${quantity} ${foodItem.name}(s) has been placed.`,
      });
      
      setFormData({
        fullName: '',
        address: '',
        mobileNumber: ''
      });
      setQuantity(1);
      
      onClose();
    } catch (error: any) {
      console.error('Error placing order:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to place order. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Left Column - Order Details */}
        <div className="space-y-6">
          <div className="bg-muted/50 p-6 rounded-lg shadow-sm">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-medium text-lg">Order Quantity</h4>
                <div className="flex items-center space-x-3">
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => handleQuantityChange(-1)}
                    disabled={quantity <= 1}
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                  <span className="font-semibold text-lg min-w-[2rem] text-center">
                    {quantity}
                  </span>
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => handleQuantityChange(1)}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <div className="pt-4 border-t border-border">
                <div className="flex justify-between items-baseline">
                  <span className="text-muted-foreground">Price per item:</span>
                  <span className="font-medium">₹{foodItem.price.toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-baseline mt-2">
                  <span className="text-muted-foreground">Total Amount:</span>
                  <span className="text-xl font-semibold text-primary">
                    ₹{(foodItem.price * quantity).toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column - Delivery Details */}
        <div className="space-y-4">
          <div className="bg-muted/50 p-6 rounded-lg shadow-sm">
            <h4 className="font-medium text-lg mb-4">Delivery Details</h4>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="fullName">Full Name</Label>
                <Input
                  id="fullName"
                  placeholder="Enter your full name"
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  required
                  disabled={isSubmitting}
                  className="bg-background"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="address">Delivery Address</Label>
                <Input
                  id="address"
                  placeholder="Enter your delivery address"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  required
                  disabled={isSubmitting}
                  className="bg-background"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="mobileNumber">Mobile Number</Label>
                <Input
                  id="mobileNumber"
                  placeholder="Enter your mobile number"
                  type="tel"
                  value={formData.mobileNumber}
                  onChange={(e) => setFormData({ ...formData, mobileNumber: e.target.value })}
                  required
                  disabled={isSubmitting}
                  pattern="[0-9]*"
                  minLength={10}
                  maxLength={10}
                  className="bg-background"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      <Button 
        type="submit" 
        className="w-full mt-6 bg-primary hover:bg-primary/90 text-white"
        disabled={isSubmitting}
      >
        {isSubmitting ? 'Placing Order...' : `Place Order • ₹${(foodItem.price * quantity).toFixed(2)}`}
      </Button>
    </form>
  );
};

export default OrderForm;
