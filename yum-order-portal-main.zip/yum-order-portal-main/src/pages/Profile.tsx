
import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { Card } from '@/components/ui/card';
import { User, Mail, Phone, Lock, MapPin, LayoutDashboard, Utensils } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { useNavigate } from 'react-router-dom';

const AdminLogin = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (email === 'admin@example.com' && password === 'admin123') {
      toast({
        title: "Admin Login Successful",
        description: "Redirecting to admin panel...",
      });
      navigate('/admin');
    } else {
      toast({
        title: "Login Failed",
        description: "Invalid admin credentials",
        variant: "destructive",
      });
    }
  };

  return (
    <form onSubmit={handleAdminLogin} className="space-y-4">
      <Input
        type="email"
        placeholder="Admin Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        required
      />
      <Input
        type="password"
        placeholder="Admin Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        required
      />
      <Button type="submit" className="w-full bg-primary">
        Login as Admin
      </Button>
    </form>
  );
};

const RiderAdminLogin = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleRiderAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (email === 'rider@example.com' && password === 'rider123') {
      toast({
        title: "Rider Admin Login Successful",
        description: "Redirecting to rider admin panel...",
      });
      navigate('/rider');
    } else {
      toast({
        title: "Login Failed",
        description: "Invalid rider admin credentials",
        variant: "destructive",
      });
    }
  };

  return (
    <form onSubmit={handleRiderAdminLogin} className="space-y-4">
      <Input
        type="email"
        placeholder="Rider Admin Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        required
      />
      <Input
        type="password"
        placeholder="Rider Admin Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        required
      />
      <Button type="submit" className="w-full bg-primary">
        Login as Rider Admin
      </Button>
    </form>
  );
};

const Profile = () => {
  const [userProfile, setUserProfile] = useState({
    name: '',
    email: '',
    phone: '',
    address: ''
  });
  const { toast } = useToast();
  const navigate = useNavigate();
  
  useEffect(() => {
    const user = localStorage.getItem('user');
    if (user) {
      const userData = JSON.parse(user);
      setUserProfile({
        name: userData.fullName || 'Not available',
        email: userData.email || 'Not available',
        phone: userData.phoneNumber || 'Not available',
        address: userData.address || 'Not available'
      });
    }
  }, []);

  return (
    <Layout>
      <div className="max-w-screen-xl mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold mb-6">Profile</h1>
        
        <Card className="p-6 space-y-4 mb-6">
          <div className="flex items-center space-x-4">
            <User className="w-5 h-5 text-primary" />
            <div>
              <p className="text-sm text-gray-500">Name</p>
              <p className="font-medium">{userProfile.name}</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Mail className="w-5 h-5 text-primary" />
            <div>
              <p className="text-sm text-gray-500">Email</p>
              <p className="font-medium">{userProfile.email}</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Phone className="w-5 h-5 text-primary" />
            <div>
              <p className="text-sm text-gray-500">Phone</p>
              <p className="font-medium">{userProfile.phone}</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <MapPin className="w-5 h-5 text-primary" />
            <div>
              <p className="text-sm text-gray-500">Address</p>
              <p className="font-medium">{userProfile.address}</p>
            </div>
          </div>
        </Card>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          {/* Rider Admin Dashboard Card */}
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <LayoutDashboard className="w-5 h-5 text-primary" />
                <h2 className="font-semibold text-lg">Rider Dashboard</h2>
              </div>
            </div>

            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" className="w-full text-base py-6 border-2 border-primary hover:bg-primary/10">
                  <Lock className="w-5 h-5 mr-2" />
                  Access Rider Dashboard
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Rider Admin Login</DialogTitle>
                </DialogHeader>
                <RiderAdminLogin />
              </DialogContent>
            </Dialog>
          </Card>

          {/* Admin Dashboard Card */}
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <Utensils className="w-5 h-5 text-primary" />
                <h2 className="font-semibold text-lg">Admin Dashboard</h2>
              </div>
            </div>

            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" className="w-full text-base py-6 border-2 border-primary hover:bg-primary/10">
                  <Lock className="w-5 h-5 mr-2" />
                  Access Admin Dashboard
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Admin Login</DialogTitle>
                </DialogHeader>
                <AdminLogin />
              </DialogContent>
            </Dialog>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default Profile;
