-- Add INSERT policy for villages table
DO $$ BEGIN
  CREATE POLICY "Villages insert allowed to anyone"
    ON public.villages FOR INSERT WITH CHECK (true);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- Add UPDATE and DELETE policies for villages table
DO $$ BEGIN
  CREATE POLICY "Villages update allowed to anyone"
    ON public.villages FOR UPDATE USING (true) WITH CHECK (true);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE POLICY "Villages delete allowed to anyone"
    ON public.villages FOR DELETE USING (true);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- Add UPDATE and DELETE policies for food_items table
DO $$ BEGIN
  CREATE POLICY "Food items update allowed to anyone"
    ON public.food_items FOR UPDATE USING (true) WITH CHECK (true);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE POLICY "Food items delete allowed to anyone"
    ON public.food_items FOR DELETE USING (true);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- Add DELETE policy for orders table
DO $$ BEGIN
  CREATE POLICY "Orders delete allowed to anyone"
    ON public.orders FOR DELETE USING (true);
EXCEPTION WHEN duplicate_object THEN NULL; END $$;