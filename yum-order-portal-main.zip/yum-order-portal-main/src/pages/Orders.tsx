
import React, { useEffect, useState } from 'react';
import Layout from '../components/Layout';
import { Card, CardContent } from '@/components/ui/card';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { supabase } from "@/integrations/supabase/client";
import { ClipboardList, Clock, MapPin, Package, CheckCircle, Truck, Home } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface Order {
  id: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
  full_name: string;
  mobile_number: string;
  address: string;
  village?: string;
  order_date: string;
  status: 'pending' | 'completed' | 'packed';
}

const Orders = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    const user = localStorage.getItem('user');
    if (!user) {
      toast({
        title: "Please Login",
        description: "You need to login to view your orders",
        variant: "destructive"
      });
      navigate('/login');
      return;
    }

    const { phoneNumber } = JSON.parse(user);
    
    const fetchOrders = async () => {
      setIsLoading(true);
      try {
        const { data, error } = await supabase
          .from('orders')
          .select('*')
          .eq('mobile_number', phoneNumber)
          .order('order_date', { ascending: false });
          
        if (error) throw error;
        
        const transformedOrders = (data || []).map(order => ({
          ...order,
          status: order.status === 'completed' ? 'completed' : 
                 order.status === 'packed' ? 'packed' : 'pending'
        })) as Order[];
        
        setOrders(transformedOrders);
      } catch (error: any) {
        console.error('Error fetching orders:', error);
        toast({
          title: "Error",
          description: "Failed to load your orders",
          variant: "destructive"
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchOrders();
  }, [navigate, toast]);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const getStatusBadge = (status: 'pending' | 'completed' | 'packed') => {
    switch(status) {
      case 'pending':
        return <Badge variant="default">In Progress</Badge>;
      case 'packed':
        return <Badge variant="secondary" className="bg-yellow-500 hover:bg-yellow-600">Packed</Badge>;
      case 'completed':
        return <Badge variant="outline">Delivered</Badge>;
      default:
        return <Badge variant="default">In Progress</Badge>;
    }
  };

  const getStatusIcon = (status: 'pending' | 'completed' | 'packed') => {
    switch(status) {
      case 'pending':
        return <Clock className="h-4 w-4" />;
      case 'packed':
        return <Truck className="h-4 w-4" />;
      case 'completed':
        return <CheckCircle className="h-4 w-4" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  };

  return (
    <Layout>
      <div className="max-w-screen-xl mx-auto px-4 py-6">
        <div className="flex items-center gap-3 mb-6">
          <ClipboardList className="h-6 w-6 text-primary" />
          <h1 className="text-2xl font-bold">Your Orders</h1>
        </div>
        
        {isLoading && (
          <div className="animate-pulse space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-gray-100 h-36 rounded-lg"></div>
            ))}
          </div>
        )}
        
        {!isLoading && orders.length === 0 && (
          <div className="text-center py-12 bg-gray-50 rounded-lg">
            <div className="mx-auto w-16 h-16 mb-4 rounded-full bg-gray-100 flex items-center justify-center">
              <Package className="text-gray-400 w-8 h-8" />
            </div>
            <h3 className="text-lg font-medium text-gray-700 mb-2">No Orders Yet</h3>
            <p className="text-gray-500 max-w-md mx-auto mb-4">
              You haven't placed any orders yet. Browse our menu and place your first order.
            </p>
            <button 
              onClick={() => navigate('/')}
              className="text-primary font-medium hover:underline"
            >
              Browse Menu
            </button>
          </div>
        )}
        
        <div className="space-y-4">
          {orders.map((order) => (
            <Card key={order.id} className="overflow-hidden animate-fade-in hover:shadow-md transition-shadow">
              <div className="md:flex">
                <div className="w-full md:w-24 h-24 bg-gray-100">
                  {order.image && (
                    <img 
                      src={order.image} 
                      alt={order.name} 
                      className="w-full h-full object-cover"
                    />
                  )}
                </div>
                <CardContent className="flex-1 p-4">
                  <div className="flex flex-col md:flex-row md:justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-lg">{order.name}</h3>
                        {getStatusBadge(order.status)}
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-500 my-1">
                        {getStatusIcon(order.status)}
                        <span>{formatDate(order.order_date)}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-500">
                        <MapPin className="h-4 w-4" />
                        <span>{order.address}</span>
                      </div>
                      {order.village && (
                        <div className="flex items-center gap-2 text-sm text-gray-500 mt-1">
                          <Home className="h-4 w-4" />
                          <span>{order.village}</span>
                        </div>
                      )}
                    </div>
                    <div className="mt-4 md:mt-0 flex items-start md:justify-end">
                      <div className="text-right">
                        <div className="font-medium text-lg text-primary">₹{order.price}</div>
                        <div className="text-sm text-gray-500">Qty: {order.quantity}</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </Layout>
  );
};

export default Orders;
