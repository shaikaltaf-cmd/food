
import { Card } from '@/components/ui/card';
import { ScrollArea } from "@/components/ui/scroll-area";
import { ShoppingBag } from 'lucide-react';
import { Order } from '@/types/admin';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface OrdersTabProps {
  orders: Order[];
  onUpdateStatus: (orderId: string, phoneNumber: string, newStatus: 'pending' | 'completed' | 'packed') => void;
}

export const OrdersTab = ({ orders, onUpdateStatus }: OrdersTabProps) => {
  const pendingOrders = orders.filter(order => order.status === 'pending');
  const packedOrders = orders.filter(order => order.status === 'packed');
  const completedOrders = orders.filter(order => order.status === 'completed');

  const OrderCard = ({ order }: { order: Order }) => (
    <Card key={order.id} className="p-4 mb-4 border-l-4 border-l-primary">
      <div className="flex items-center gap-4">
        {order.image && (
          <img 
            src={order.image} 
            alt={order.name || 'Food item'} 
            className="w-20 h-20 object-cover rounded"
          />
        )}
        <div className="flex-1">
          <h3 className="font-semibold">{order.name}</h3>
          <p className="text-sm text-gray-500">
            Ordered by: {order.full_name}
          </p>
          <p className="text-sm text-gray-500">
            Phone: {order.mobile_number}
          </p>
          <p className="text-sm text-gray-500">
            Address: {order.address}
          </p>
          <p className="text-sm text-gray-500">
            Date: {new Date(order.order_date).toLocaleString()}
          </p>
        </div>
        <div className="text-right space-y-2">
          <p className="font-semibold">₹{order.price.toFixed(2)}</p>
          <select
            className="px-2 py-1 rounded border"
            value={order.status}
            onChange={(e) => onUpdateStatus(order.id, order.mobile_number, e.target.value as 'pending' | 'completed' | 'packed')}
          >
            <option value="pending">Pending</option>
            <option value="packed">Packed</option>
            <option value="completed">Completed</option>
          </select>
        </div>
      </div>
    </Card>
  );

  return (
    <div className="space-y-4">
      <Tabs defaultValue="pending" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="pending" className="relative">
            Pending Orders
            {pendingOrders.length > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {pendingOrders.length}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="packed" className="relative">
            Packed Orders
            {packedOrders.length > 0 && (
              <span className="absolute -top-1 -right-1 bg-yellow-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {packedOrders.length}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="completed">
            Completed Orders
            {completedOrders.length > 0 && (
              <span className="ml-2 text-sm text-gray-500">
                ({completedOrders.length})
              </span>
            )}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pending">
          <ScrollArea className="h-[600px]">
            {pendingOrders.map((order) => (
              <OrderCard key={order.id} order={order} />
            ))}
            {pendingOrders.length === 0 && (
              <div className="text-center py-10 text-gray-500">
                No pending orders
              </div>
            )}
          </ScrollArea>
        </TabsContent>

        <TabsContent value="packed">
          <ScrollArea className="h-[600px]">
            {packedOrders.map((order) => (
              <OrderCard key={order.id} order={order} />
            ))}
            {packedOrders.length === 0 && (
              <div className="text-center py-10 text-gray-500">
                No packed orders
              </div>
            )}
          </ScrollArea>
        </TabsContent>

        <TabsContent value="completed">
          <ScrollArea className="h-[600px]">
            {completedOrders.map((order) => (
              <OrderCard key={order.id} order={order} />
            ))}
            {completedOrders.length === 0 && (
              <div className="text-center py-10 text-gray-500">
                No completed orders
              </div>
            )}
          </ScrollArea>
        </TabsContent>
      </Tabs>
    </div>
  );
};
