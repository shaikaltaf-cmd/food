
import React from 'react';
import { Home, Search, ClipboardList, User, LogIn, Menu } from 'lucide-react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const Layout = ({ children }: { children: React.ReactNode }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const { toast } = useToast();
  const isLoggedIn = localStorage.getItem('user') !== null;

  const handleLogout = () => {
    localStorage.removeItem('user');
    toast({
      title: "Logged Out",
      description: "You have been successfully logged out",
    });
    navigate('/login');
  };

  // Determine if the current page is the rider admin panel
  const isRiderPanel = location.pathname === '/rider' || location.pathname === '/rider-admin';

  const navigation = [
    { name: 'Home', icon: Home, path: '/' },
    { name: 'Search', icon: Search, path: '/search' },
    { name: 'Orders', icon: ClipboardList, path: '/orders' },
    { name: 'Profile', icon: User, path: '/profile' }
  ];

  const userName = isLoggedIn ? JSON.parse(localStorage.getItem('user') || '{}').fullName || 'User' : null;

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="fixed top-0 left-0 right-0 bg-white border-b border-gray-200 px-4 py-3 z-50 shadow-sm">
        <div className="max-w-screen-xl mx-auto flex items-center justify-between">
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              <span className="font-bold text-xl text-primary">EIT</span>
              {isRiderPanel && (
                <span className="ml-2 text-sm text-gray-500 hidden sm:inline">Rider Panel</span>
              )}
            </Link>
          </div>
          
          <div className="flex items-center gap-2">
            {isLoggedIn ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                      {userName?.charAt(0).toUpperCase() || 'U'}
                    </div>
                    <span className="hidden md:inline">{userName}</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => navigate('/profile')}>
                    <User className="mr-2 h-4 w-4" />
                    Profile
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleLogout} className="text-red-500">
                    <LogIn className="mr-2 h-4 w-4" />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              location.pathname !== '/login' && (
                <Button onClick={() => navigate('/login')} variant="default" size="sm" className="flex items-center gap-2">
                  <LogIn className="w-4 h-4" />
                  <span className="hidden md:inline">Sign In</span>
                </Button>
              )
            )}
          </div>
        </div>
      </header>
      
      <main className="pb-20 pt-16">
        {children}
      </main>
      
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-3 z-40 shadow-[0_-1px_3px_rgba(0,0,0,0.05)]">
        <div className="max-w-screen-xl mx-auto">
          <div className="flex justify-around items-center">
            {navigation.map((item) => {
              const isActive = location.pathname === item.path;
              return (
                <Link
                  key={item.name}
                  to={item.path}
                  className={`flex flex-col items-center p-1 rounded-lg transition-colors ${
                    isActive 
                      ? 'text-primary' 
                      : 'text-gray-500 hover:text-gray-900'
                  }`}
                >
                  <item.icon className="w-5 h-5" />
                  <span className="text-xs mt-1">{item.name}</span>
                </Link>
              );
            })}
          </div>
        </div>
      </nav>
    </div>
  );
};

export default Layout;
