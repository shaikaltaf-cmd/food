
import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { ShoppingBag, UserCog, PlusCircle, MapPin, Building2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { OrdersTab } from '@/components/admin/OrdersTab';
import { UsersTab } from '@/components/admin/UsersTab';
import { FoodItemsTab } from '@/components/admin/FoodItemsTab';
import { CitiesTab } from '@/components/admin/CitiesTab';
import { OrderStatisticsChart } from '@/components/admin/OrderStatisticsChart';
import { Order, User, FoodItem, Village } from '@/types/admin';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

const AdminPanel = () => {
  const { toast } = useToast();
  const [foodName, setFoodName] = useState('');
  const [price, setPrice] = useState('');
  const [category, setCategory] = useState('');
  const [description, setDescription] = useState('');
  const [village, setVillage] = useState('');
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isCityLoading, setIsCityLoading] = useState(false);
  const [onlineUsers, setOnlineUsers] = useState<Set<string>>(new Set());
  const [foodItems, setFoodItems] = useState<FoodItem[]>([]);
  const [allOrders, setAllOrders] = useState<Order[]>([]);
  const [cities, setCities] = useState<Village[]>([]);
  const [cityName, setCityName] = useState('');
  const [filterVillage, setFilterVillage] = useState<string>('all');
  const [timeFilter, setTimeFilter] = useState<string>('all');

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "Error",
          description: "Image size should be less than 5MB",
          variant: "destructive",
        });
        return;
      }
      setSelectedImage(file);
      toast({
        title: "Image Selected",
        description: "Your image has been selected successfully",
      });
    }
  };

  const handleAddFood = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      if (!selectedImage) {
        throw new Error("Please select an image");
      }

      if (!foodName.trim() || !price || !category.trim() || !village.trim()) {
        throw new Error("Please fill in all required fields");
      }

      const base64Image = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          const result = reader.result;
          if (typeof result === 'string') {
            resolve(result);
          } else {
            reject(new Error('Failed to convert image'));
          }
        };
        reader.onerror = () => reject(reader.error);
        reader.readAsDataURL(selectedImage);
      });

      console.log('Attempting to insert food item...');
      const { data, error } = await supabase
        .from('food_items')
        .insert([
          {
            name: foodName.trim(),
            price: parseFloat(price),
            image: base64Image,
            category: category.trim(),
            description: description.trim() || null,
            village: village.trim(),
          }
        ])
        .select('*')
        .single();

      if (error) {
        console.error('Supabase error:', error);
        throw error;
      }

      console.log('Food item added successfully:', data);
      toast({
        title: "Success",
        description: "Food item added successfully",
      });

      setFoodName('');
      setPrice('');
      setCategory('');
      setDescription('');
      setVillage('');
      setSelectedImage(null);
      if (document.getElementById('image') instanceof HTMLInputElement) {
        (document.getElementById('image') as HTMLInputElement).value = '';
      }

      fetchFoodItems();
    } catch (error) {
      console.error('Error in handleAddFood:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to add food item",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddCity = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsCityLoading(true);

    try {
      if (!cityName.trim()) {
        throw new Error("Please enter a city name");
      }

      console.log('Attempting to insert city...');
      const { data, error } = await supabase
        .from('villages')
        .insert([
          {
            name: cityName.trim(),
          }
        ])
        .select('*')
        .single();

      if (error) {
        console.error('Supabase error:', error);
        throw error;
      }

      console.log('City added successfully:', data);
      toast({
        title: "Success",
        description: "City added successfully",
      });

      setCityName('');
      fetchCities();
    } catch (error) {
      console.error('Error in handleAddCity:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to add city",
        variant: "destructive",
      });
    } finally {
      setIsCityLoading(false);
    }
  };

  const handleDeleteFoodItem = async (id: string) => {
    try {
      const { error } = await supabase
        .from('food_items')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Food item deleted successfully",
      });
      
      fetchFoodItems();
    } catch (error) {
      console.error('Error deleting food item:', error);
      toast({
        title: "Error",
        description: "Failed to delete food item",
        variant: "destructive",
      });
    }
  };

  const handleDeleteCity = async (id: string) => {
    try {
      const { error } = await supabase
        .from('villages')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "City deleted successfully",
      });
      
      fetchCities();
    } catch (error) {
      console.error('Error deleting city:', error);
      toast({
        title: "Error",
        description: "Failed to delete city",
        variant: "destructive",
      });
    }
  };

  const handleUpdateOrderStatus = async (orderId: string, phoneNumber: string, newStatus: 'pending' | 'completed' | 'packed') => {
    try {
      const { error } = await supabase
        .from('orders')
        .update({ status: newStatus })
        .eq('id', orderId);

      if (error) {
        throw error;
      }

      setAllOrders(prevOrders => 
        prevOrders.map(order => 
          order.id === orderId 
            ? { ...order, status: newStatus }
            : order
        )
      );

      toast({
        title: "Status Updated",
        description: `Order status changed to ${newStatus}`,
        duration: 3000,
      });
    } catch (error) {
      console.error('Error updating order status:', error);
      toast({
        title: "Error",
        description: "Failed to update order status",
        variant: "destructive",
        duration: 3000,
      });
    }
  };

  const fetchFoodItems = async () => {
    try {
      let query = supabase
        .from('food_items')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (filterVillage && filterVillage !== 'all') {
        query = query.eq('village', filterVillage);
      }
      
      const { data, error } = await query;

      if (error) throw error;
      setFoodItems(data || []);
    } catch (error) {
      console.error('Error fetching food items:', error);
      toast({
        title: "Error",
        description: "Failed to fetch food items",
        variant: "destructive",
      });
    }
  };

  const fetchCities = async () => {
    try {
      const { data, error } = await supabase
        .from('villages')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setCities(data || []);
    } catch (error) {
      console.error('Error fetching cities:', error);
      toast({
        title: "Error",
        description: "Failed to fetch cities",
        variant: "destructive",
      });
    }
  };

  const fetchAllOrders = async () => {
    try {
      let query = supabase
        .from('orders')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (filterVillage && filterVillage !== 'all') {
        query = query.eq('village', filterVillage);
      }
      
      const { data: dbOrders, error } = await query;

      if (error) {
        throw error;
      }

      if (dbOrders) {
        const formattedOrders: Order[] = dbOrders.map(order => ({
          id: order.id,
          name: order.name,
          price: order.price,
          image: order.image,
          full_name: order.full_name,
          mobile_number: order.mobile_number,
          address: order.address,
          village: order.village,
          order_date: order.order_date || order.created_at || new Date().toISOString(),
          status: order.status === 'completed' ? 'completed' : 
                 order.status === 'packed' ? 'packed' : 'pending',
          created_at: order.created_at
        }));

        setAllOrders(formattedOrders);
        updateUsersFromOrders(formattedOrders);
        console.log('Orders fetched:', formattedOrders.length, 'total orders');
      }
    } catch (error) {
      console.error('Error fetching orders:', error);
      toast({
        title: "Error",
        description: "Failed to fetch orders",
        variant: "destructive",
        duration: 3000,
      });
    }
  };

  const updateUsersFromOrders = (orders: Order[]) => {
    const userMap = new Map<string, User>();
    
    orders.forEach(order => {
      if (!userMap.has(order.mobile_number)) {
        userMap.set(order.mobile_number, {
          id: order.mobile_number,
          fullName: order.full_name,
          mobileNumber: order.mobile_number,
          address: order.address,
          orderCount: 1,
          village: order.village,
          lastSeen: order.order_date,
          online: onlineUsers.has(order.mobile_number)
        });
      } else {
        const user = userMap.get(order.mobile_number)!;
        user.orderCount += 1;
        if (new Date(order.order_date) > new Date(user.lastSeen!)) {
          user.lastSeen = order.order_date;
        }
        userMap.set(order.mobile_number, user);
      }
    });
    
    setUsers(Array.from(userMap.values()));
  };

  useEffect(() => {
    fetchAllOrders();
    fetchFoodItems();
  }, [filterVillage]);

  useEffect(() => {
    const ordersChannel = supabase.channel('db-orders')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'orders'
        },
        (payload) => {
          console.log('Real-time order update received:', payload);
          fetchAllOrders();
        }
      )
      .subscribe((status) => {
        console.log('Orders channel status:', status);
      });

    const userChannel = supabase.channel('online-users')
      .on('presence', { event: 'sync' }, () => {
        const state = userChannel.presenceState();
        console.log('User presence state:', state);
        const onlineUserIds = new Set(
          Object.values(state)
            .flat()
            .map((presence: any) => presence.user_id)
        );
        setOnlineUsers(onlineUserIds);
      })
      .subscribe(async (status) => {
        if (status === 'SUBSCRIBED') {
          await userChannel.track({
            user_id: 'admin',
            online_at: new Date().toISOString(),
          });
        }
      });

    const villagesChannel = supabase.channel('db-villages')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'villages'
        },
        (payload) => {
          console.log('Real-time villages update received:', payload);
          fetchCities();
        }
      )
      .subscribe((status) => {
        console.log('Villages channel status:', status);
      });

    fetchAllOrders();
    fetchFoodItems();
    fetchCities();

    return () => {
      console.log('Cleaning up subscriptions...');
      supabase.removeChannel(ordersChannel);
      supabase.removeChannel(userChannel);
      supabase.removeChannel(villagesChannel);
    };
  }, []);

  return (
    <Layout>
      <div className="min-h-screen bg-gray-50 p-4">
        <div className="max-w-screen-xl mx-auto">
          <h1 className="text-2xl font-bold mb-6">Admin Dashboard</h1>
          
          <div className="mb-4 flex flex-wrap items-center gap-4">
            <div className="flex items-center">
              <MapPin className="h-5 w-5 mr-2 text-primary" />
              <label htmlFor="filterVillage" className="block text-sm font-medium mr-3">Filter by City:</label>
              <Select 
                value={filterVillage} 
                onValueChange={setFilterVillage}
              >
                <SelectTrigger id="filterVillage" className="max-w-xs">
                  <SelectValue placeholder="All Cities" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Cities</SelectItem>
                  {cities.map((city) => (
                    <SelectItem key={city.id} value={city.name}>
                      {city.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              {filterVillage !== 'all' && (
                <Badge className="ml-2 bg-primary">{filterVillage}</Badge>
              )}
            </div>
            
            <div className="flex items-center ml-auto">
              <label htmlFor="timeFilter" className="block text-sm font-medium mr-3">Time Period:</label>
              <Select 
                value={timeFilter} 
                onValueChange={setTimeFilter}
              >
                <SelectTrigger id="timeFilter" className="max-w-xs">
                  <SelectValue placeholder="All Time" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Time</SelectItem>
                  <SelectItem value="day">Last 24 Hours</SelectItem>
                  <SelectItem value="week">Last 7 Days</SelectItem>
                  <SelectItem value="month">Last 30 Days</SelectItem>
                  <SelectItem value="year">Last Year</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {/* Add statistics charts */}
          <OrderStatisticsChart 
            orders={allOrders} 
            foodItems={foodItems} 
            timeFilter={timeFilter}
          />
          
          <Tabs defaultValue="orders" className="space-y-6">
            <TabsList>
              <TabsTrigger value="orders" className="relative">
                <ShoppingBag className="w-4 h-4 mr-2" />
                Orders
                {allOrders.filter(order => order.status === 'pending').length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {allOrders.filter(order => order.status === 'pending').length}
                  </span>
                )}
              </TabsTrigger>
              <TabsTrigger value="users">
                <UserCog className="w-4 h-4 mr-2" />
                Users
                {users.length > 0 && (
                  <span className="ml-2 text-sm text-gray-500">
                    ({users.length})
                  </span>
                )}
              </TabsTrigger>
              <TabsTrigger value="food-items">
                <PlusCircle className="w-4 h-4 mr-2" />
                Food Items
              </TabsTrigger>
              <TabsTrigger value="cities">
                <Building2 className="w-4 h-4 mr-2" />
                Cities
                {cities.length > 0 && (
                  <span className="ml-2 text-sm text-gray-500">
                    ({cities.length})
                  </span>
                )}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="orders">
              <OrdersTab 
                orders={allOrders}
                onUpdateStatus={handleUpdateOrderStatus}
              />
            </TabsContent>

            <TabsContent value="users">
              <UsersTab users={users} />
            </TabsContent>

            <TabsContent value="food-items">
              <FoodItemsTab
                foodItems={foodItems}
                isLoading={isLoading}
                foodName={foodName}
                price={price}
                category={category}
                description={description}
                village={village}
                selectedImage={selectedImage}
                onFoodNameChange={setFoodName}
                onPriceChange={setPrice}
                onCategoryChange={setCategory}
                onDescriptionChange={setDescription}
                onVillageChange={setVillage}
                onImageChange={handleImageChange}
                onAddFood={handleAddFood}
                onDeleteFood={handleDeleteFoodItem}
                cities={cities}
              />
            </TabsContent>

            <TabsContent value="cities">
              <CitiesTab
                cities={cities}
                isLoading={isCityLoading}
                cityName={cityName}
                onCityNameChange={setCityName}
                onAddCity={handleAddCity}
                onDeleteCity={handleDeleteCity}
              />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </Layout>
  );
};

export default AdminPanel;
