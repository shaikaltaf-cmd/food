
import { useEffect, useState } from 'react';
import { Card } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Circle } from 'lucide-react';
import { User } from '@/types/admin';
import { supabase } from '@/integrations/supabase/client';

interface UsersTabProps {
  users: User[];
}

export const UsersTab = ({ users }: UsersTabProps) => {
  const [supabaseUsers, setSupabaseUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        setLoading(true);
        const { data, error } = await supabase
          .from('users' as any)
          .select('*')
          .order('last_login', { ascending: false });

        if (error) {
          console.error('Error fetching users:', error);
          return;
        }

        if (data) {
          const formattedUsers = data.map((user: any) => ({
            id: user.id,
            fullName: user.full_name,
            mobileNumber: user.phone_number,
            address: user.address,
            email: user.email,
            orderCount: 0, // We could fetch this from orders table
            lastSeen: user.last_login,
            online: new Date(user.last_login).getTime() > Date.now() - 5 * 60 * 1000 // Online if active in last 5 minutes
          }));
          setSupabaseUsers(formattedUsers);
        }
      } catch (error) {
        console.error('Error:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchUsers();
  }, []);

  const allUsers = [...users, ...supabaseUsers];

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold mb-4">User Management</h2>
      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Status</TableHead>
              <TableHead>Full Name</TableHead>
              <TableHead>Mobile Number</TableHead>
              <TableHead>Address</TableHead>
              <TableHead>Total Orders</TableHead>
              <TableHead>Last Seen</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-4">
                  Loading users...
                </TableCell>
              </TableRow>
            ) : (
              allUsers.map((user) => (
                <TableRow key={user.id}>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Circle className={`w-3 h-3 ${user.online ? 'fill-green-500 text-green-500' : 'fill-gray-300 text-gray-300'}`} />
                      <span className={`text-sm ${user.online ? 'text-green-500' : 'text-gray-500'}`}>
                        {user.online ? 'Online' : 'Offline'}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>{user.fullName}</TableCell>
                  <TableCell>{user.mobileNumber}</TableCell>
                  <TableCell>{user.address}</TableCell>
                  <TableCell>{user.orderCount}</TableCell>
                  <TableCell>
                    {user.lastSeen ? new Date(user.lastSeen).toLocaleString() : 'N/A'}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
        {allUsers.length === 0 && !loading && (
          <div className="text-center py-10 text-gray-500">
            No users yet
          </div>
        )}
      </Card>
    </div>
  );
};
