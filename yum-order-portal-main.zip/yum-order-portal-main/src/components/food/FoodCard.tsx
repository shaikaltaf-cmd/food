
import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger,
} from "@/components/ui/dialog";
import { FoodItem } from '@/types/food';
import { AspectRatio } from '@/components/ui/aspect-ratio';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useNavigate } from 'react-router-dom';
import { supabase } from "@/integrations/supabase/client";
import { Plus, Minus, MapPin } from 'lucide-react';

interface FoodCardProps {
  item: FoodItem;
}

const FoodCard = ({ item }: FoodCardProps) => {
  const [isOpen, setIsOpen] = React.useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();
  const [quantity, setQuantity] = React.useState(1);
  const [formData, setFormData] = React.useState({
    fullName: '',
    address: '',
    phoneNumber: '',
    village: item.village || ''
  });
  const [isSubmitting, setIsSubmitting] = React.useState(false);

  // Auto-fill form data from user profile when dialog opens
  React.useEffect(() => {
    if (isOpen) {
      const userJson = localStorage.getItem('user');
      if (userJson) {
        const userData = JSON.parse(userJson);
        setFormData({
          fullName: userData.fullName || '',
          address: userData.address || '',
          phoneNumber: userData.phoneNumber || '',
          village: item.village || ''
        });
      }
    }
  }, [isOpen, item.village]);

  const handleQuantityChange = (increment: number) => {
    setQuantity(prev => Math.max(1, prev + increment));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const user = localStorage.getItem('user');
      if (!user) {
        toast({
          title: "Please Login",
          description: "You need to login before placing an order",
          variant: "destructive"
        });
        navigate('/login');
        return;
      }

      const orderData = {
        name: item.name,
        price: item.price * quantity,
        image: item.image,
        quantity: quantity,
        full_name: formData.fullName,
        mobile_number: formData.phoneNumber,
        address: formData.address,
        village: item.village,
        order_date: new Date().toISOString(),
        status: 'pending' as const
      };

      const { data, error } = await supabase
        .from('orders')
        .insert([orderData])
        .select()
        .single();

      if (error) {
        throw error;
      }

      toast({
        title: "Order Placed Successfully",
        description: `Your order for ${quantity} ${item.name}(s) has been placed.`,
      });
      
      setFormData({
        fullName: '',
        address: '',
        phoneNumber: '',
        village: item.village || ''
      });
      setQuantity(1);
      
      setIsOpen(false);
    } catch (error: any) {
      console.error('Error placing order:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to place order. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="overflow-hidden animate-fade-in group hover:shadow-md transition-shadow duration-200 flex flex-col h-full">
      <div className="relative">
        <AspectRatio ratio={3/2}>
          <img
            src={item.image}
            alt={item.name}
            className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-200"
          />
        </AspectRatio>
        {item.village && (
          <div className="absolute top-2 right-2 bg-white/80 backdrop-blur-sm px-2 py-1 rounded-full text-xs flex items-center">
            <MapPin className="h-3 w-3 mr-1 text-primary" />
            {item.village}
          </div>
        )}
      </div>
      <div className="p-2 flex flex-col flex-grow">
        <h3 className="font-semibold text-sm line-clamp-1">{item.name}</h3>
        {item.description && (
          <p className="text-xs text-gray-500 line-clamp-2 mt-1">{item.description}</p>
        )}
        <div className="flex justify-between items-center mt-auto pt-2">
          <span className="text-primary font-medium text-sm">
            <span className="font-normal text-xs">₹</span>
            {item.price.toFixed(2)}
          </span>
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button size="sm" className="bg-primary hover:bg-primary/90 text-white h-7 px-2 text-xs">
                Order
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle className="text-xl font-bold">Place Order</DialogTitle>
                <DialogDescription className="text-muted-foreground mt-1">
                  Complete your order for {item.name}
                </DialogDescription>
              </DialogHeader>
              
              <form onSubmit={handleSubmit} className="mt-4">
                <div className="flex items-start space-x-4 mb-6">
                  <div className="w-24 h-24 rounded overflow-hidden flex-shrink-0">
                    <img 
                      src={item.image} 
                      alt={item.name} 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">{item.name}</h3>
                    {item.description && (
                      <p className="text-sm text-gray-500 mb-1">{item.description}</p>
                    )}
                    <p className="text-primary font-medium text-lg">₹{item.price.toFixed(2)}</p>
                    {item.village && (
                      <div className="flex items-center text-xs text-gray-500 mt-1">
                        <MapPin className="h-3 w-3 mr-1 text-primary" />
                        <span>Available in {item.village}</span>
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="space-y-1.5">
                    <Label htmlFor="fullName">Full Name</Label>
                    <Input
                      id="fullName"
                      placeholder="John Doe"
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      required
                      className="border-primary/20"
                    />
                  </div>
                  
                  <div className="space-y-1.5">
                    <Label htmlFor="address">Delivery Address</Label>
                    <Input
                      id="address"
                      placeholder="123 Main St, Apartment 4B"
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      required
                      className="border-primary/20"
                    />
                  </div>
                  
                  <div className="space-y-1.5">
                    <Label htmlFor="phoneNumber">Phone Number</Label>
                    <Input
                      id="phoneNumber"
                      placeholder="123-456-7890"
                      value={formData.phoneNumber}
                      onChange={(e) => setFormData({ ...formData, phoneNumber: e.target.value })}
                      required
                      className="border-primary/20"
                    />
                  </div>
                  
                  <div className="space-y-1.5">
                    <Label>Quantity</Label>
                    <div className="flex items-center">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        className="h-8 w-8 rounded-md p-0"
                        onClick={() => handleQuantityChange(-1)}
                        disabled={quantity <= 1}
                      >
                        <Minus className="h-3 w-3" />
                      </Button>
                      <div className="w-12 text-center font-medium mx-2">
                        {quantity}
                      </div>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        className="h-8 w-8 rounded-md p-0"
                        onClick={() => handleQuantityChange(1)}
                      >
                        <Plus className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-between items-center mt-6 mb-4">
                  <span className="font-medium">Total:</span>
                  <span className="text-primary font-bold text-xl">₹{(item.price * quantity).toFixed(2)}</span>
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full bg-primary hover:bg-primary/90"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? 'Processing...' : 'Place Order'}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </Card>
  );
};

export default FoodCard;
