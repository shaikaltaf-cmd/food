
import { supabase } from "@/integrations/supabase/client";
import { FoodItem } from "@/types/food";

// Modified to work with React Query's queryFn pattern
export const fetchFoodItems = async ({ queryKey }: { queryKey: string[] }): Promise<FoodItem[]> => {
  const [_, village] = queryKey;
  
  let query = supabase
    .from('food_items')
    .select('*')
    .order('created_at', { ascending: false });
  
  if (village) {
    query = query.eq('village', village);
  }
  
  const { data, error } = await query;
  
  if (error) throw error;
  return data || [];
};

// Simple version for direct calls with memoization capabilities
export const fetchFoodItemsByVillage = async (village?: string): Promise<FoodItem[]> => {
  // Use a more efficient query with only needed fields
  let query = supabase
    .from('food_items')
    .select('*')
    .order('created_at', { ascending: false });
  
  if (village) {
    query = query.eq('village', village);
  }
  
  // Set a timeout to prevent hanging requests
  const timeoutPromise = new Promise<never>((_, reject) => {
    setTimeout(() => reject(new Error('Request timeout')), 10000);
  });
  
  try {
    // Race between the query and the timeout
    const { data, error } = await Promise.race([
      query,
      timeoutPromise
    ]) as { data: FoodItem[], error: any };
    
    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error fetching food items:', error);
    return [];
  }
};
