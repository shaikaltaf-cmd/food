
import React from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Check, X } from "lucide-react";

interface FilterOptionsProps {
  dietaryFilters: string[];
  selectedDietary: string[];
  priceRange: [number, number];
  maxPrice: number;
  onDietaryChange: (filter: string) => void;
  onPriceChange: (range: [number, number]) => void;
  onClearFilters: () => void;
}

const FilterOptions = ({
  dietaryFilters,
  selectedDietary,
  priceRange,
  maxPrice,
  onDietaryChange,
  onPriceChange,
  onClearFilters,
}: FilterOptionsProps) => {
  return (
    <div className="bg-white rounded-lg shadow-sm border p-4 mb-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-medium text-sm">Filter Options</h3>
        {(selectedDietary.length > 0 || priceRange[1] < maxPrice) && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onClearFilters}
            className="h-8 text-xs"
          >
            <X className="h-3 w-3 mr-1" />
            Clear Filters
          </Button>
        )}
      </div>

      <div className="space-y-4">
        <div>
          <Label className="text-xs mb-2 block">Dietary Restrictions</Label>
          <div className="flex flex-wrap gap-2">
            {dietaryFilters.map((filter) => (
              <Button
                key={filter}
                size="sm"
                variant={selectedDietary.includes(filter) ? "default" : "outline"}
                className="h-7 text-xs"
                onClick={() => onDietaryChange(filter)}
              >
                {selectedDietary.includes(filter) && (
                  <Check className="h-3 w-3 mr-1" />
                )}
                {filter}
              </Button>
            ))}
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-2">
            <Label className="text-xs">Price Range</Label>
            <span className="text-xs font-medium">
              ₹{priceRange[0]} - ₹{priceRange[1]}
            </span>
          </div>
          <Slider
            defaultValue={priceRange}
            min={0}
            max={maxPrice}
            step={10}
            value={priceRange}
            onValueChange={(value) => onPriceChange(value as [number, number])}
            className="my-2"
          />
          <div className="flex justify-between text-xs text-gray-500">
            <span>₹0</span>
            <span>₹{maxPrice}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FilterOptions;
