import React, { useEffect, useState, useCallback, useMemo } from 'react';
import Layout from '../components/Layout';
import { useToast } from '@/hooks/use-toast';
import { supabase, getUserProfile, updateUserCity } from "@/integrations/supabase/client";
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { fetchFoodItemsByVillage } from '@/services/foodService';
import FoodCard from '@/components/food/FoodCard';
import { Utensils, MapPin, ChevronRight, Store } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FoodItem } from '@/types/food';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useIsMobile } from "@/hooks/use-mobile";

const Index = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [selectedVillage, setSelectedVillage] = useState<string>('');
  const [villages, setVillages] = useState<string[]>([]);
  const [userPhoneNumber, setUserPhoneNumber] = useState<string | null>(null);
  const [selectOpen, setSelectOpen] = useState<boolean>(true);
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const isMobile = useIsMobile();
  
  useEffect(() => {
    const getSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user?.phone) {
        setUserPhoneNumber(session.user.phone);
      } else {
        const storedPhone = localStorage.getItem('userPhoneNumber');
        if (storedPhone) {
          setUserPhoneNumber(storedPhone);
        }
      }
    };
    
    getSession();
  }, []);
  
  const fetchVillages = useCallback(async () => {
    const { data, error } = await supabase
      .from('villages')
      .select('name')
      .order('name');
      
    if (error) {
      console.error('Error fetching villages:', error);
      return;
    }
    
    const villageNames = data.map(v => v.name);
    setVillages(villageNames);
    
    if (userPhoneNumber && !selectedVillage) {
      const userProfile = await getUserProfile(userPhoneNumber);
      if (userProfile?.selected_city) {
        setSelectedVillage(userProfile.selected_city);
      } else if (villageNames.length > 0) {
        setSelectedVillage(villageNames[0]);
        if (userPhoneNumber) {
          updateUserCity(userPhoneNumber, villageNames[0])
            .catch(err => console.error('Error setting default city:', err));
        }
      }
    } else if (villageNames.length > 0 && !selectedVillage) {
      setSelectedVillage(villageNames[0]);
    }
    
    setSelectOpen(true);
    setTimeout(() => setSelectOpen(false), 1000);
  }, [userPhoneNumber, selectedVillage]);
  
  useEffect(() => {
    fetchVillages();
  }, [fetchVillages]);
  
  const handleVillageChange = async (village: string) => {
    setSelectedVillage(village);
    setActiveCategory('all');
    
    if (userPhoneNumber) {
      try {
        await updateUserCity(userPhoneNumber, village);
        toast({
          title: "City Updated",
          description: `Your preferred city has been set to ${village}`,
        });
      } catch (error) {
        console.error('Error updating preferred city:', error);
      }
    }
  };

  const { data: foodItems = [], isLoading, error } = useQuery({
    queryKey: ['foodItems', selectedVillage],
    queryFn: () => fetchFoodItemsByVillage(selectedVillage),
    enabled: !!selectedVillage,
    refetchOnWindowFocus: false,
    staleTime: 5 * 60 * 1000,
  });

  const foodByCategory = useMemo(() => foodItems.reduce((acc, item) => {
    if (!item.category) return acc;
    
    if (!acc[item.category]) {
      acc[item.category] = [];
    }
    acc[item.category].push(item);
    return acc;
  }, {} as Record<string, typeof foodItems>), [foodItems]);

  const categories = useMemo(() => Object.keys(foodByCategory).sort(), [foodByCategory]);

  const filteredFoodItems: FoodItem[] = useMemo(() => activeCategory === 'all' 
    ? foodItems 
    : foodByCategory[activeCategory] || [], [activeCategory, foodItems, foodByCategory]);

  useEffect(() => {
    const channel = supabase
      .channel('food_items_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'food_items'
        },
        async (payload) => {
          console.log('Real-time update received:', payload);
          
          if (payload.eventType === 'INSERT') {
            toast({
              title: "New Item Added!",
              description: `A new item has been added to the menu.`,
            });
          }
          
          await queryClient.invalidateQueries({ queryKey: ['foodItems'] });
        }
      )
      .subscribe();

    const villagesChannel = supabase
      .channel('villages_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'villages'
        },
        async () => {
          const { data } = await supabase
            .from('villages')
            .select('name')
            .order('name');
            
          if (data) {
            setVillages(data.map(v => v.name));
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
      supabase.removeChannel(villagesChannel);
    };
  }, [queryClient, toast]);

  return (
    <Layout>
      <div className="max-w-screen-xl mx-auto px-4 py-6">
        <header className="mb-8">
          <div className="bg-gradient-to-r from-primary/20 to-primary/5 p-6 rounded-xl shadow-sm">
            <div className="flex flex-col md:flex-row items-center justify-between mb-4">
              <div className="flex items-center gap-3 mb-4 md:mb-0">
                <div className="bg-primary text-white p-3 rounded-full">
                  <Store className="h-6 w-6" />
                </div>
                <div>
                  <h1 className="text-2xl md:text-3xl font-bold tracking-tight">
                    Food Delivery
                  </h1>
                  <p className="text-gray-500 mt-1 text-sm">
                    Fresh & delicious food delivered to your doorstep
                  </p>
                </div>
              </div>
              
              <div className="flex items-center gap-3 bg-white/80 p-2 rounded-lg shadow-sm">
                <MapPin className="h-4 w-4 text-primary" />
                <Select 
                  value={selectedVillage} 
                  onValueChange={handleVillageChange}
                  open={selectOpen}
                  onOpenChange={setSelectOpen}
                >
                  <SelectTrigger className="w-[180px] border-none shadow-none focus:ring-0">
                    <SelectValue placeholder="Select your city" />
                  </SelectTrigger>
                  <SelectContent>
                    {villages.map((village) => (
                      <SelectItem key={village} value={village}>
                        {village}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            {!isLoading && categories.length > 0 && (
              <div className="mt-4 bg-white/70 rounded-lg p-1">
                <div className="overflow-x-auto pb-2 -mx-2 px-2">
                  <Tabs 
                    value={activeCategory} 
                    onValueChange={setActiveCategory} 
                    className="w-full"
                  >
                    <TabsList className="bg-transparent p-0 flex-nowrap overflow-x-auto w-max min-w-full">
                      <TabsTrigger 
                        value="all" 
                        className="data-[state=active]:bg-primary data-[state=active]:text-white rounded-md whitespace-nowrap flex-shrink-0"
                      >
                        <span className="px-1">All Items</span>
                      </TabsTrigger>
                      {categories.map((category) => (
                        <TabsTrigger 
                          key={category} 
                          value={category}
                          className="data-[state=active]:bg-primary data-[state=active]:text-white rounded-md whitespace-nowrap mx-1 bg-white flex-shrink-0"
                        >
                          <span className="px-1">{category}</span>
                        </TabsTrigger>
                      ))}
                    </TabsList>
                  </Tabs>
                </div>
              </div>
            )}
          </div>
        </header>
        
        {isLoading && (
          <div className="text-center py-10">
            <div className="animate-pulse flex flex-col items-center gap-4">
              <div className="h-8 w-64 bg-gray-200 rounded"></div>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 w-full">
                {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
                  <div key={i} className="h-40 bg-gray-200 rounded-lg"></div>
                ))}
              </div>
            </div>
          </div>
        )}

        {error && (
          <div className="text-center py-10 text-red-500">
            Error loading food items. Please try again later.
          </div>
        )}
        
        {!isLoading && villages.length === 0 && (
          <div className="text-center py-10 text-gray-500">
            No cities available yet. Please check back later.
          </div>
        )}
        
        {!isLoading && selectedVillage && filteredFoodItems.length === 0 && (
          <div className="text-center py-10 text-gray-500">
            No food items available for {selectedVillage}
            {activeCategory !== 'all' ? ` in ${activeCategory} category` : ''}
          </div>
        )}
        
        {activeCategory === 'all' ? (
          categories.map((category, index) => (
            <div key={category} className="mb-12">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-gray-800 flex items-center">
                  <Badge 
                    variant="outline" 
                    className="mr-2 bg-primary/10 text-primary border-primary/20"
                  >
                    {category}
                  </Badge>
                </h2>
                <Badge variant="outline" className="flex items-center gap-1">
                  {foodByCategory[category].length} items
                  <ChevronRight className="h-3 w-3" />
                </Badge>
              </div>
              <Card className="overflow-hidden mb-4" style={{ 
                background: index % 2 === 0 ? 'linear-gradient(to right, rgba(255,250,245,0.8), rgba(255,255,255,0.9))' : 'linear-gradient(to right, rgba(245,250,255,0.8), rgba(255,255,255,0.9))'
              }}>
                <CardContent className="p-4">
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                    {foodByCategory[category].map((item) => (
                      <FoodCard key={item.id} item={item} />
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          ))
        ) : (
          <Card className="overflow-hidden mb-4">
            <CardContent className="p-4">
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                {filteredFoodItems.map((item) => (
                  <FoodCard key={item.id} item={item} />
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </Layout>
  );
};

export default Index;
