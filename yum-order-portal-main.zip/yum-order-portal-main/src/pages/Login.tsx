import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardContent, CardFooter, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { useNavigate } from 'react-router-dom';
import { LogIn, Phone, User, Lock, ArrowRight, Mail, MapPin } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase, storeUserProfile, getUserProfile } from "@/integrations/supabase/client";
import { SupabaseUser } from '@/types/admin';

const Login = () => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    const user = localStorage.getItem('user');
    if (user) {
      const userData = JSON.parse(user);
      if (userData.isLoggedIn) {
        navigate('/');
      }
    }
  }, [navigate]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!/^\d{10}$/.test(phoneNumber)) {
      toast({
        title: "Invalid Phone Number",
        description: "Please enter a valid 10-digit phone number",
        variant: "destructive",
        duration: 3000,
      });
      return;
    }

    if (!password) {
      toast({
        title: "Password Required",
        description: "Please enter your password",
        variant: "destructive",
        duration: 3000,
      });
      return;
    }
    
    const existingUsersString = localStorage.getItem('registeredUsers');
    const existingUsers = existingUsersString ? JSON.parse(existingUsersString) : [];
    
    const localUser = existingUsers.find((u: any) => u.phoneNumber === phoneNumber);
    
    if (localUser && localUser.password !== password) {
      toast({
        title: "Invalid Password",
        description: "The password you entered is incorrect",
        variant: "destructive",
        duration: 3000,
      });
      return;
    }
    
    try {
      let userProfile: SupabaseUser | null = await getUserProfile(phoneNumber);
      
      if (!userProfile && localUser) {
        await storeUserProfile({
          phone_number: phoneNumber,
          full_name: localUser.fullName,
          email: localUser.email,
          address: localUser.address
        });
        
        userProfile = await getUserProfile(phoneNumber);
      }
      
      if (!userProfile && !localUser) {
        toast({
          title: "User Not Found",
          description: "This phone number is not registered. Please sign up.",
          variant: "destructive",
          duration: 3000,
        });
        return;
      }
      
      if (userProfile) {
        await supabase
          .from('profiles')
          .update({ last_login: new Date().toISOString() })
          .eq('phone_number', phoneNumber);
      }
      
      localStorage.setItem('user', JSON.stringify({ 
        phoneNumber, 
        fullName: userProfile ? userProfile.full_name : localUser.fullName,
        email: userProfile ? userProfile.email : localUser.email,
        address: userProfile ? userProfile.address : localUser.address,
        isLoggedIn: true 
      }));
      
      toast({
        title: "Login Successful",
        description: "Welcome back!",
        duration: 3000,
      });
      
      navigate('/');
      
    } catch (error) {
      console.error("Login error:", error);
      toast({
        title: "Login Failed",
        description: "An error occurred during login. Please try again.",
        variant: "destructive",
        duration: 3000,
      });
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!fullName || fullName.trim().length === 0) {
      toast({
        title: "Full Name Required",
        description: "Please enter your full name",
        variant: "destructive",
        duration: 3000,
      });
      return;
    }

    if (!/^\d{10}$/.test(phoneNumber)) {
      toast({
        title: "Invalid Phone Number",
        description: "Please enter a valid 10-digit phone number",
        variant: "destructive",
        duration: 3000,
      });
      return;
    }

    if (!email.includes('@')) {
      toast({
        title: "Invalid Email",
        description: "Please enter a valid email address",
        variant: "destructive",
        duration: 3000,
      });
      return;
    }

    if (password !== confirmPassword) {
      toast({
        title: "Password Mismatch",
        description: "Passwords do not match",
        variant: "destructive",
        duration: 3000,
      });
      return;
    }
    
    try {
      const { data: existingUser } = await supabase
        .from('profiles')
        .select('phone_number')
        .eq('phone_number', phoneNumber)
        .maybeSingle();
      
      if (existingUser) {
        toast({
          title: "User Already Exists",
          description: "This phone number is already registered. Please login.",
          variant: "destructive",
          duration: 3000,
        });
        return;
      }
      
      const existingUsersString = localStorage.getItem('registeredUsers');
      const existingUsers = existingUsersString ? JSON.parse(existingUsersString) : [];
      
      if (existingUsers.some((user: any) => user.phoneNumber === phoneNumber)) {
        toast({
          title: "User Already Exists",
          description: "This phone number is already registered. Please login.",
          variant: "destructive",
          duration: 3000,
        });
        return;
      }
      
      await storeUserProfile({
        phone_number: phoneNumber,
        full_name: fullName,
        email,
        address
      });
      
      const newUser = {
        phoneNumber,
        fullName,
        email,
        address,
        password,
        registeredAt: new Date().toISOString()
      };
      
      existingUsers.push(newUser);
      localStorage.setItem('registeredUsers', JSON.stringify(existingUsers));
      
      localStorage.setItem('user', JSON.stringify({ 
        phoneNumber, 
        fullName,
        email,
        address,
        isLoggedIn: true 
      }));
      
      toast({
        title: "Registration Successful",
        description: "Your account has been created!",
        duration: 3000,
      });
      
      navigate('/');
    } catch (error) {
      console.error("Registration error:", error);
      toast({
        title: "Registration Failed",
        description: "An error occurred during registration. Please try again.",
        variant: "destructive",
        duration: 3000,
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="space-y-1 bg-primary/5 rounded-t-lg">
          <div className="flex justify-center mb-2">
            <div className="bg-primary/10 p-3 rounded-full">
              <User className="w-8 h-8 text-primary" />
            </div>
          </div>
          <CardTitle className="text-center text-2xl font-bold">Welcome</CardTitle>
          <CardDescription className="text-center">
            Sign in to your account or create a new one
          </CardDescription>
        </CardHeader>
        
        <Tabs defaultValue="login" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mt-4 mx-4">
            <TabsTrigger value="login">Login</TabsTrigger>
            <TabsTrigger value="register">Register</TabsTrigger>
          </TabsList>
          
          <TabsContent value="login">
            <CardContent className="pt-6">
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <div className="relative">
                    <Phone className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="Phone Number"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="password"
                      type="password"
                      placeholder="Password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>

                <Button type="submit" className="w-full">
                  Sign In <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </form>
            </CardContent>
          </TabsContent>
          
          <TabsContent value="register">
            <CardContent className="pt-6">
              <form onSubmit={handleRegister} className="space-y-4">
                <div className="space-y-2">
                  <div className="relative">
                    <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="fullName"
                      type="text"
                      placeholder="Full Name"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="relative">
                    <Phone className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="registerPhone"
                      type="tel"
                      placeholder="Phone Number"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="Email Address"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="relative">
                    <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="address"
                      type="text"
                      placeholder="Delivery Address"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="registerPassword"
                      type="password"
                      placeholder="Password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="confirmPassword"
                      type="password"
                      placeholder="Confirm Password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>

                <Button type="submit" className="w-full">
                  Create Account <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </form>
            </CardContent>
          </TabsContent>
        </Tabs>
        
        <CardFooter className="flex flex-col">
          <p className="text-xs text-center text-gray-500 mt-2">
            By continuing, you agree to our Terms of Service and Privacy Policy
          </p>
        </CardFooter>
      </Card>
    </div>
  );
};

export default Login;
