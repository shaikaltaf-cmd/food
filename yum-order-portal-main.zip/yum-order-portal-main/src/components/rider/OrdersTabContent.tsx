
import React from 'react';
import { Order } from '@/types/admin';
import { ScrollArea } from "@/components/ui/scroll-area";
import OrderCard from './OrderCard';

interface OrdersTabContentProps {
  orders: Order[];
  onUpdateOrderStatus: (orderId: string, newStatus: 'pending' | 'completed' | 'packed') => void;
  onPrintBill: (order: Order) => void;
}

const OrdersTabContent = ({ orders, onUpdateOrderStatus, onPrintBill }: OrdersTabContentProps) => {
  return (
    <ScrollArea className="h-[600px]">
      {orders.map((order) => (
        <OrderCard 
          key={order.id} 
          order={order}
          onUpdateStatus={onUpdateOrderStatus}
          onPrintBill={onPrintBill}
        />
      ))}
      {orders.length === 0 && (
        <div className="text-center py-10 text-gray-500">
          No orders in this category
        </div>
      )}
    </ScrollArea>
  );
};

export default OrdersTabContent;
