
import React from 'react';
import { Printer } from 'lucide-react';
import { Order } from '@/types/admin';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog';

interface OrderReceiptDialogProps {
  selectedOrder: Order | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onPrint: () => void;
}

const OrderReceiptDialog = ({ 
  selectedOrder,
  open,
  onOpenChange,
  onPrint 
}: OrderReceiptDialogProps) => {
  if (!selectedOrder) return null;
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Order Receipt</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="border rounded-lg p-4">
            <h3 className="font-bold border-b pb-2">Customer Information</h3>
            <div className="grid grid-cols-2 gap-2 mt-2">
              <p className="text-sm text-gray-500">Name:</p>
              <p className="text-sm">{selectedOrder.full_name}</p>
              <p className="text-sm text-gray-500">Phone:</p>
              <p className="text-sm">{selectedOrder.mobile_number}</p>
              <p className="text-sm text-gray-500">Address:</p>
              <p className="text-sm">{selectedOrder.address}</p>
              <p className="text-sm text-gray-500">City:</p>
              <p className="text-sm">{selectedOrder.village || 'Not specified'}</p>
            </div>
          </div>

          <div className="border rounded-lg p-4">
            <h3 className="font-bold border-b pb-2">Order Information</h3>
            <div className="grid grid-cols-2 gap-2 mt-2">
              <p className="text-sm text-gray-500">Item:</p>
              <p className="text-sm">{selectedOrder.name}</p>
              <p className="text-sm text-gray-500">Price:</p>
              <p className="text-sm font-semibold">₹{selectedOrder.price.toFixed(2)}</p>
              <p className="text-sm text-gray-500">Date:</p>
              <p className="text-sm">{new Date(selectedOrder.order_date).toLocaleString()}</p>
              <p className="text-sm text-gray-500">Status:</p>
              <Badge className={
                selectedOrder.status === 'completed' ? 'bg-green-500' : 
                selectedOrder.status === 'packed' ? 'bg-yellow-500' : 'bg-red-500'
              }>
                {selectedOrder.status.toUpperCase()}
              </Badge>
            </div>
          </div>

          <div className="flex justify-end">
            <Button onClick={onPrint} className="flex items-center gap-2">
              <Printer className="h-4 w-4" />
              Print Receipt
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default OrderReceiptDialog;
