
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ImageIcon, PlusCircle, Trash2, Tags, Plus } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { FoodItem, Village } from '@/types/admin';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Badge } from '@/components/ui/badge';
import { useState } from 'react';

interface FoodItemsTabProps {
  foodItems: FoodItem[];
  isLoading: boolean;
  foodName: string;
  price: string;
  category: string;
  description: string;
  village: string;
  selectedImage: File | null;
  onFoodNameChange: (value: string) => void;
  onPriceChange: (value: string) => void;
  onCategoryChange: (value: string) => void;
  onDescriptionChange: (value: string) => void;
  onVillageChange: (value: string) => void;
  onImageChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onAddFood: (e: React.FormEvent) => void;
  onDeleteFood: (id: string) => void;
  cities?: Village[];
}

// Define our predefined categories
const PREDEFINED_CATEGORIES = ['BAKERY', 'FAST FOOD', 'PANO PURI', 'CHICKEN PAKODA', 'SNACKS', 'ICE CREAM', 'COOL DRINKS'];

export const FoodItemsTab = ({
  foodItems,
  isLoading,
  foodName,
  price,
  category,
  description,
  village,
  selectedImage,
  onFoodNameChange,
  onPriceChange,
  onCategoryChange,
  onDescriptionChange,
  onVillageChange,
  onImageChange,
  onAddFood,
  onDeleteFood,
  cities = [],
}: FoodItemsTabProps) => {
  const [isAddingCategory, setIsAddingCategory] = useState(false);
  const [newCategory, setNewCategory] = useState('');
  const [customCategories, setCustomCategories] = useState<string[]>([]);

  const handleAddCategory = () => {
    if (newCategory.trim() && !PREDEFINED_CATEGORIES.includes(newCategory.trim().toUpperCase()) && 
        !customCategories.includes(newCategory.trim().toUpperCase())) {
      setCustomCategories([...customCategories, newCategory.trim().toUpperCase()]);
      setNewCategory('');
      setIsAddingCategory(false);
    }
  };

  // Combine predefined and custom categories
  const allCategories = [...PREDEFINED_CATEGORIES, ...customCategories];

  const categoryGroups = foodItems.reduce((acc, item) => {
    const categories = Object.keys(acc);
    if (!categories.includes(item.category)) {
      acc[item.category] = 0;
    }
    acc[item.category]++;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="space-y-4">
      <Card className="p-6 bg-white">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold flex items-center gap-2">
            <Tags className="w-5 h-5 text-primary" />
            Categories Overview
          </h2>
          <Button variant="outline" size="sm" onClick={() => setIsAddingCategory(true)} className="flex items-center gap-1">
            <Plus className="h-4 w-4" />
            Add Category
          </Button>
        </div>

        <div className="flex flex-wrap gap-2">
          {Object.entries(categoryGroups).map(([cat, count]) => (
            <Badge 
              key={cat} 
              variant="outline" 
              className="px-3 py-2 text-sm flex items-center gap-2 bg-primary/5"
            >
              {cat}
              <span className="bg-primary/20 text-primary rounded-full px-2 py-0.5 text-xs">
                {count}
              </span>
            </Badge>
          ))}
        </div>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {foodItems.map((item) => (
          <Card key={item.id} className="overflow-hidden">
            <div className="relative">
              {item.image && (
                <img 
                  src={item.image} 
                  alt={item.name} 
                  className="w-full h-48 object-cover"
                />
              )}
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button
                    variant="destructive"
                    size="icon"
                    className="absolute top-2 right-2"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Delete Food Item</AlertDialogTitle>
                    <AlertDialogDescription>
                      Are you sure you want to delete "{item.name}"? This action cannot be undone.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={() => onDeleteFood(item.id)}
                      className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                    >
                      Delete
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
              <Badge className="absolute bottom-2 left-2 bg-primary/80">
                {item.category}
              </Badge>
            </div>
            <div className="p-4">
              <h3 className="font-semibold text-lg">{item.name}</h3>
              {item.description && (
                <p className="text-sm text-gray-600 mt-1 line-clamp-2">{item.description}</p>
              )}
              <div className="flex justify-between items-center mt-2">
                <p className="font-semibold">₹{item.price.toFixed(2)}</p>
                {item.village && (
                  <span className="text-xs bg-gray-100 px-2 py-1 rounded-full">
                    {item.village}
                  </span>
                )}
              </div>
            </div>
          </Card>
        ))}
      </div>
      
      <Card className="p-6">
        <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
          <PlusCircle className="w-6 h-6 text-primary" />
          Add New Food
        </h2>
        <form onSubmit={onAddFood} className="space-y-4">
          <div>
            <label htmlFor="foodName" className="block text-sm font-medium mb-1">Food Name *</label>
            <Input
              id="foodName"
              value={foodName}
              onChange={(e) => onFoodNameChange(e.target.value)}
              placeholder="Enter food name"
              required
            />
          </div>
          
          <div>
            <label htmlFor="description" className="block text-sm font-medium mb-1">Description</label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => onDescriptionChange(e.target.value)}
              placeholder="Enter food description"
              className="min-h-[80px]"
            />
          </div>
          
          <div>
            <label htmlFor="price" className="block text-sm font-medium mb-1">Price *</label>
            <Input
              id="price"
              type="number"
              min="0"
              step="0.01"
              value={price}
              onChange={(e) => onPriceChange(e.target.value)}
              placeholder="Enter price"
              required
            />
          </div>

          <div>
            <label htmlFor="category" className="block text-sm font-medium mb-1">Category *</label>
            <Select 
              value={category} 
              onValueChange={onCategoryChange}
            >
              <SelectTrigger id="category">
                <SelectValue placeholder="Select a category" />
              </SelectTrigger>
              <SelectContent>
                {allCategories.map((cat) => (
                  <SelectItem key={cat} value={cat}>
                    {cat}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <label htmlFor="village" className="block text-sm font-medium mb-1">City/Town *</label>
            <Select 
              value={village} 
              onValueChange={onVillageChange}
            >
              <SelectTrigger id="village">
                <SelectValue placeholder="Select a city/town" />
              </SelectTrigger>
              <SelectContent>
                {cities.map((city) => (
                  <SelectItem key={city.id} value={city.name}>
                    {city.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label htmlFor="image" className="block text-sm font-medium mb-1">Food Image *</label>
            <div className="mt-1 flex items-center gap-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => document.getElementById('image')?.click()}
                className="flex items-center gap-2"
              >
                <ImageIcon className="w-4 h-4" />
                {selectedImage ? 'Change Image' : 'Upload Image'}
              </Button>
              {selectedImage && (
                <span className="text-sm text-gray-500">
                  {selectedImage.name}
                </span>
              )}
              <input
                id="image"
                type="file"
                accept="image/*"
                onChange={onImageChange}
                className="hidden"
              />
            </div>
          </div>

          <Button 
            type="submit" 
            className="w-full"
            disabled={isLoading}
          >
            {isLoading ? 'Adding Food Item...' : 'Add Food Item'}
          </Button>
        </form>
      </Card>

      {/* Add Category Dialog */}
      <Dialog open={isAddingCategory} onOpenChange={setIsAddingCategory}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Add New Category</DialogTitle>
            <DialogDescription>
              Create a new food category that will be available when adding food items.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <label htmlFor="new-category" className="text-sm font-medium">
                Category Name
              </label>
              <Input
                id="new-category"
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
                placeholder="Enter category name (e.g. BREAKFAST)"
                className="uppercase"
              />
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">Cancel</Button>
            </DialogClose>
            <Button onClick={handleAddCategory} disabled={!newCategory.trim()}>
              Add Category
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
