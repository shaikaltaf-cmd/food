
import { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from "@/integrations/supabase/client";
import { Order } from '@/types/admin';

export const useOrderManagement = () => {
  const { toast } = useToast();
  const [orders, setOrders] = useState<Order[]>([]);
  const [villages, setVillages] = useState<string[]>([]);
  const [filterVillage, setFilterVillage] = useState<string>('all');
  const [isLoading, setIsLoading] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const fetchVillages = async () => {
    try {
      const { data, error } = await supabase
        .from('villages')
        .select('name')
        .order('name');
        
      if (error) throw error;
      
      const villageNames = data.map(v => v.name);
      setVillages(villageNames);
    } catch (error) {
      console.error('Error fetching villages:', error);
      toast({
        title: "Error",
        description: "Failed to fetch cities",
        variant: "destructive",
      });
    }
  };

  const fetchOrders = async () => {
    setIsLoading(true);
    try {
      let query = supabase
        .from('orders')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (filterVillage && filterVillage !== 'all') {
        query = query.eq('village', filterVillage);
      }
      
      const { data, error } = await query;

      if (error) throw error;
      
      setOrders(data as Order[]);
    } catch (error) {
      console.error('Error fetching orders:', error);
      toast({
        title: "Error",
        description: "Failed to fetch orders",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdateOrderStatus = async (orderId: string, newStatus: 'pending' | 'completed' | 'packed') => {
    try {
      const { error } = await supabase
        .from('orders')
        .update({ status: newStatus })
        .eq('id', orderId);

      if (error) throw error;

      setOrders(prevOrders => 
        prevOrders.map(order => 
          order.id === orderId 
            ? { ...order, status: newStatus }
            : order
        )
      );

      toast({
        title: "Status Updated",
        description: `Order status changed to ${newStatus}`,
        duration: 3000,
      });
    } catch (error) {
      console.error('Error updating order status:', error);
      toast({
        title: "Error",
        description: "Failed to update order status",
        variant: "destructive",
      });
    }
  };

  const handlePrintBill = (order: Order) => {
    setSelectedOrder(order);
  };

  const printBill = () => {
    if (!selectedOrder) return;
    
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      toast({
        title: "Print Error",
        description: "Please allow pop-ups to print the bill",
        variant: "destructive",
      });
      return;
    }
    
    printWindow.document.write(`
      <html>
        <head>
          <title>Order Receipt</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            .header { text-align: center; margin-bottom: 20px; }
            .bill-info { margin-bottom: 20px; }
            .divider { border-top: 1px dashed #ccc; margin: 10px 0; }
            .item-details { margin-bottom: 20px; }
            .total { font-weight: bold; text-align: right; }
            .customer-info { margin-bottom: 20px; }
            .thank-you { text-align: center; margin-top: 30px; font-style: italic; }
          </style>
        </head>
        <body>
          <div class="header">
            <h2>Food Delivery Receipt</h2>
            <p>Order ID: ${selectedOrder.id.substring(0, 8)}</p>
            <p>${new Date(selectedOrder.order_date).toLocaleString()}</p>
          </div>
          
          <div class="customer-info">
            <h3>Customer Details</h3>
            <p><strong>Name:</strong> ${selectedOrder.full_name}</p>
            <p><strong>Phone:</strong> ${selectedOrder.mobile_number}</p>
            <p><strong>Address:</strong> ${selectedOrder.address}</p>
            <p><strong>City:</strong> ${selectedOrder.village || 'Not specified'}</p>
          </div>
          
          <div class="divider"></div>
          
          <div class="item-details">
            <h3>Order Details</h3>
            <p><strong>Item:</strong> ${selectedOrder.name}</p>
            <p><strong>Quantity:</strong> 1</p>
            <p><strong>Price:</strong> ₹${selectedOrder.price.toFixed(2)}</p>
          </div>
          
          <div class="divider"></div>
          
          <div class="total">
            <p>Total Amount: ₹${selectedOrder.price.toFixed(2)}</p>
          </div>
          
          <div class="divider"></div>
          
          <div class="thank-you">
            <p>Thank you for your order!</p>
            <p>Status: ${selectedOrder.status.toUpperCase()}</p>
          </div>
        </body>
      </html>
    `);
    
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
    setTimeout(() => printWindow.close(), 1000);
  };

  useEffect(() => {
    fetchVillages();
    fetchOrders();
    
    const ordersChannel = supabase.channel('orders-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'orders'
        },
        () => {
          fetchOrders();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(ordersChannel);
    };
  }, []);

  useEffect(() => {
    fetchOrders();
  }, [filterVillage]);

  return {
    orders,
    villages,
    filterVillage,
    setFilterVillage,
    isLoading,
    selectedOrder,
    setSelectedOrder,
    handleUpdateOrderStatus,
    handlePrintBill,
    printBill
  };
};
