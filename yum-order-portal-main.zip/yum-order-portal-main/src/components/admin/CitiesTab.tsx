
import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { PlusCircle, Trash2 } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Village } from '@/types/admin';

interface CitiesTabProps {
  cities: Village[];
  isLoading: boolean;
  cityName: string;
  onCityNameChange: (value: string) => void;
  onAddCity: (e: React.FormEvent) => void;
  onDeleteCity: (id: string) => void;
}

export const CitiesTab = ({
  cities,
  isLoading,
  cityName,
  onCityNameChange,
  onAddCity,
  onDeleteCity,
}: CitiesTabProps) => {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {cities.map((city) => (
          <Card key={city.id} className="p-4">
            <div className="flex justify-between items-center">
              <h3 className="font-semibold text-lg">{city.name}</h3>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button
                    variant="destructive"
                    size="icon"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Delete City</AlertDialogTitle>
                    <AlertDialogDescription>
                      Are you sure you want to delete "{city.name}"? This action cannot be undone.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={() => onDeleteCity(city.id)}
                      className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                    >
                      Delete
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
            <p className="text-sm text-gray-500 mt-2">Added on {new Date(city.created_at).toLocaleDateString()}</p>
          </Card>
        ))}
      </div>
      
      <Card className="p-6">
        <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
          <PlusCircle className="w-6 h-6 text-primary" />
          Add New City
        </h2>
        <form onSubmit={onAddCity} className="space-y-4">
          <div>
            <label htmlFor="cityName" className="block text-sm font-medium mb-1">City Name *</label>
            <Input
              id="cityName"
              value={cityName}
              onChange={(e) => onCityNameChange(e.target.value)}
              placeholder="Enter city name"
              required
            />
          </div>

          <Button 
            type="submit" 
            className="w-full"
            disabled={isLoading}
          >
            {isLoading ? 'Adding City...' : 'Add City'}
          </Button>
        </form>
      </Card>
    </div>
  );
};
