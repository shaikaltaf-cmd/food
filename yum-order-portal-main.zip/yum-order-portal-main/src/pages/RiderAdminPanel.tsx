
import React from 'react';
import Layout from '../components/Layout';
import { Truck, Filter } from 'lucide-react';
import { Order } from '@/types/admin';
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

import OrdersTabContent from '@/components/rider/OrdersTabContent';
import OrderReceiptDialog from '@/components/rider/OrderReceiptDialog';
import { useOrderManagement } from '@/hooks/useOrderManagement';

const RiderAdminPanel = () => {
  const {
    orders,
    villages,
    filterVillage,
    setFilterVillage,
    isLoading,
    selectedOrder,
    setSelectedOrder,
    handleUpdateOrderStatus,
    handlePrintBill,
    printBill
  } = useOrderManagement();

  // Filter orders by status
  const pendingOrders = orders.filter(order => order.status === 'pending');
  const packedOrders = orders.filter(order => order.status === 'packed');
  const completedOrders = orders.filter(order => order.status === 'completed');

  return (
    <Layout>
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold flex items-center">
            <Truck className="mr-2 h-6 w-6 text-primary" />
            Rider Dashboard
          </h1>
          
          <div className="flex items-center gap-2">
            <Filter className="h-5 w-5 text-gray-500" />
            <Select 
              value={filterVillage} 
              onValueChange={setFilterVillage}
            >
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="All Cities" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Cities</SelectItem>
                {villages.map((village) => (
                  <SelectItem key={village} value={village}>
                    {village}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            {filterVillage !== 'all' && (
              <Badge className="ml-2 bg-primary">{filterVillage}</Badge>
            )}
          </div>
        </div>

        {isLoading ? (
          <div className="text-center py-10">
            <div className="animate-pulse flex flex-col items-center gap-4">
              <div className="h-8 w-64 bg-gray-200 rounded"></div>
              <div className="grid grid-cols-1 gap-3 w-full">
                {[1, 2, 3, 4].map((i) => (
                  <div key={i} className="h-24 bg-gray-200 rounded-lg"></div>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <Tabs defaultValue="pending" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="pending" className="relative">
                Pending Orders
                {pendingOrders.length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {pendingOrders.length}
                  </span>
                )}
              </TabsTrigger>
              <TabsTrigger value="packed" className="relative">
                Packed Orders
                {packedOrders.length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-yellow-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {packedOrders.length}
                  </span>
                )}
              </TabsTrigger>
              <TabsTrigger value="completed">
                Completed Orders
                {completedOrders.length > 0 && (
                  <span className="ml-2 text-sm text-gray-500">
                    ({completedOrders.length})
                  </span>
                )}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="pending">
              <OrdersTabContent 
                orders={pendingOrders} 
                onUpdateOrderStatus={handleUpdateOrderStatus}
                onPrintBill={handlePrintBill}
              />
            </TabsContent>

            <TabsContent value="packed">
              <OrdersTabContent 
                orders={packedOrders} 
                onUpdateOrderStatus={handleUpdateOrderStatus}
                onPrintBill={handlePrintBill}
              />
            </TabsContent>

            <TabsContent value="completed">
              <OrdersTabContent 
                orders={completedOrders} 
                onUpdateOrderStatus={handleUpdateOrderStatus}
                onPrintBill={handlePrintBill}
              />
            </TabsContent>
          </Tabs>
        )}

        <OrderReceiptDialog
          selectedOrder={selectedOrder}
          open={!!selectedOrder}
          onOpenChange={(open) => !open && setSelectedOrder(null)}
          onPrint={printBill}
        />
      </div>
    </Layout>
  );
};

export default RiderAdminPanel;
