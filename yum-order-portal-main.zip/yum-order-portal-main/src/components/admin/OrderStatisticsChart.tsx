
import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import { Order, FoodItem } from '@/types/admin';
import { format, subDays, subMonths, subYears, isAfter } from 'date-fns';

interface OrderStatisticsChartProps {
  orders: Order[];
  foodItems: FoodItem[];
  timeFilter?: string;
}

export const OrderStatisticsChart = ({ orders, foodItems, timeFilter = 'all' }: OrderStatisticsChartProps) => {
  const filteredOrders = useMemo(() => {
    const now = new Date();
    let cutoffDate: Date | null = null;
    
    if (timeFilter === 'day') {
      cutoffDate = subDays(now, 1);
    } else if (timeFilter === 'week') {
      cutoffDate = subDays(now, 7);
    } else if (timeFilter === 'month') {
      cutoffDate = subMonths(now, 1);
    } else if (timeFilter === 'year') {
      cutoffDate = subYears(now, 1);
    }
    
    if (!cutoffDate) return orders;
    
    return orders.filter(order => 
      isAfter(new Date(order.order_date), cutoffDate!)
    );
  }, [orders, timeFilter]);

  const villageData = useMemo(() => {
    const villages: Record<string, number> = {};
    
    filteredOrders.forEach(order => {
      if (order.village) {
        villages[order.village] = (villages[order.village] || 0) + 1;
      }
    });
    
    return Object.entries(villages).map(([name, value]) => ({
      name,
      value,
    }));
  }, [filteredOrders]);

  const categoryData = useMemo(() => {
    const categories: Record<string, number> = {};
    
    // First, create a map of food item ID to category
    const foodItemToCategory = foodItems.reduce((acc, item) => {
      acc[item.name] = item.category;
      return acc;
    }, {} as Record<string, string>);
    
    // Count orders by category
    filteredOrders.forEach(order => {
      const category = foodItemToCategory[order.name];
      if (category) {
        categories[category] = (categories[category] || 0) + 1;
      }
    });
    
    return Object.entries(categories).map(([name, value]) => ({
      name,
      value,
    }));
  }, [filteredOrders, foodItems]);

  // Generate data for top food items by revenue
  const topFoodItemsData = useMemo(() => {
    // Create a map of item names to total revenue and count
    const itemData: Record<string, { revenue: number; count: number; category: string }> = {};
    
    filteredOrders.forEach(order => {
      if (!itemData[order.name]) {
        const foodItem = foodItems.find(item => item.name === order.name);
        itemData[order.name] = {
          revenue: 0,
          count: 0,
          category: foodItem?.category || 'Unknown'
        };
      }
      
      itemData[order.name].revenue += order.price;
      itemData[order.name].count += 1;
    });
    
    return Object.entries(itemData)
      .map(([name, data]) => ({
        name,
        revenue: data.revenue,
        orders: data.count,
        category: data.category
      }))
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 10); // Top 10 items by revenue
  }, [filteredOrders, foodItems]);

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#A569BD', '#5DADE2', '#58D68D'];

  const getTimeFilterLabel = () => {
    switch(timeFilter) {
      case 'day': return 'Last 24 Hours';
      case 'week': return 'Last 7 Days';
      case 'month': return 'Last 30 Days';
      case 'year': return 'Last Year';
      default: return 'All Time';
    }
  };

  return (
    <div className="space-y-4 mb-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Orders by City ({getTimeFilterLabel()})</CardTitle>
          </CardHeader>
          <CardContent>
            {villageData.length > 0 ? (
              <div className="w-full h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={villageData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {villageData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [`${value} orders`, 'Count']} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="flex items-center justify-center h-[300px] text-gray-500">
                No order data available
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Orders by Category ({getTimeFilterLabel()})</CardTitle>
          </CardHeader>
          <CardContent>
            {categoryData.length > 0 ? (
              <div className="w-full h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={categoryData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {categoryData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [`${value} orders`, 'Count']} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="flex items-center justify-center h-[300px] text-gray-500">
                No order data available
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Food Item Revenue Chart */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-medium">
            Top Food Items Revenue ({getTimeFilterLabel()})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {topFoodItemsData.length > 0 ? (
            <div className="w-full h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={topFoodItemsData}
                  margin={{
                    top: 20,
                    right: 30,
                    left: 20,
                    bottom: 70
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="name" 
                    angle={-45} 
                    textAnchor="end" 
                    height={70}
                    tick={{fontSize: 12}}
                  />
                  <YAxis />
                  <Tooltip
                    formatter={(value, name, props) => {
                      if (name === 'revenue') return [`₹${value}`, 'Revenue'];
                      return [value, name];
                    }}
                    labelFormatter={(label) => {
                      const item = topFoodItemsData.find(item => item.name === label);
                      return `${label} (${item?.category || 'Unknown'})`;
                    }}
                  />
                  <Legend />
                  <Bar dataKey="revenue" name="Revenue" fill="#8884d8" />
                  <Bar dataKey="orders" name="Order Count" fill="#82ca9d" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="flex items-center justify-center h-[300px] text-gray-500">
              No data available for the selected time period
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
