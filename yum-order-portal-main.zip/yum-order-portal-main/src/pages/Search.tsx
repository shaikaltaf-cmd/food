
import React, { useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { Input } from '@/components/ui/input';
import { Search as SearchIcon, Filter, X } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { fetchFoodItems } from '@/services/foodService';
import FoodCard from '@/components/food/FoodCard';
import { FoodItem } from '@/types/food';
import FilterOptions from '@/components/food/FilterOptions';
import { Button } from '@/components/ui/button';
import { 
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";

const Search = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState<FoodItem[]>([]);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  
  // Filter states
  const [selectedDietary, setSelectedDietary] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 1000]);
  const [maxPrice, setMaxPrice] = useState(1000);
  
  const dietaryFilters = ['Vegetarian', 'Non-Vegetarian', 'Vegan', 'Gluten-Free', 'Spicy'];
  
  const { data: foodItems = [], isLoading } = useQuery({
    queryKey: ['foodItems', ''],
    queryFn: fetchFoodItems,
  });

  useEffect(() => {
    // Find max price for slider
    if (foodItems.length > 0) {
      const highestPrice = Math.max(...foodItems.map(item => item.price));
      const roundedMax = Math.ceil(highestPrice / 100) * 100;
      setMaxPrice(roundedMax);
      setPriceRange([0, roundedMax]);
    }
  }, [foodItems]);

  useEffect(() => {
    if (searchTerm.length > 1) {
      // Generate suggestions based on food names, categories
      const nameMatches = [...new Set(foodItems
        .filter(item => item.name.toLowerCase().includes(searchTerm.toLowerCase()))
        .map(item => item.name))];
        
      const categoryMatches = [...new Set(foodItems
        .filter(item => item.category && item.category.toLowerCase().includes(searchTerm.toLowerCase()))
        .map(item => item.category))];
        
      const villageMatches = [...new Set(foodItems
        .filter(item => item.village && item.village.toLowerCase().includes(searchTerm.toLowerCase()))
        .map(item => item.village))];
        
      const allSuggestions = [
        ...nameMatches.map(name => `${name}`),
        ...categoryMatches.map(category => `Category: ${category}`),
        ...villageMatches.map(village => `Location: ${village}`)
      ].slice(0, 5);
      
      setSuggestions(allSuggestions);
      setShowSuggestions(allSuggestions.length > 0);
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  }, [searchTerm, foodItems]);

  useEffect(() => {
    applyFilters();
  }, [searchTerm, selectedDietary, priceRange, foodItems]);

  const applyFilters = () => {
    if (!searchTerm.trim() && selectedDietary.length === 0 && priceRange[0] === 0 && priceRange[1] === maxPrice) {
      setSearchResults([]);
      return;
    }

    let filtered = foodItems;
    
    // Apply search term filter
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(item => 
        item.name.toLowerCase().includes(term) ||
        (item.category && item.category.toLowerCase().includes(term)) ||
        (item.village && item.village.toLowerCase().includes(term)) ||
        (item.description && item.description.toLowerCase().includes(term))
      );
    }
    
    // Apply dietary filters
    if (selectedDietary.length > 0) {
      filtered = filtered.filter(item => {
        // This is a simple simulation - in a real app, you'd have dietary info for each item
        const isVeg = item.description?.toLowerCase().includes('veg') || false;
        const isNonVeg = item.description?.toLowerCase().includes('chicken') || 
                        item.description?.toLowerCase().includes('meat') || 
                        item.name.toLowerCase().includes('chicken') || false;
        const isSpicy = item.description?.toLowerCase().includes('spicy') || 
                       item.name.toLowerCase().includes('spicy') || false;
        
        return (selectedDietary.includes('Vegetarian') && isVeg) ||
               (selectedDietary.includes('Non-Vegetarian') && isNonVeg) ||
               (selectedDietary.includes('Spicy') && isSpicy) ||
               // For demo purposes, let's assume Vegan and Gluten-Free are random
               (selectedDietary.includes('Vegan') && isVeg && item.id.charCodeAt(0) % 2 === 0) ||
               (selectedDietary.includes('Gluten-Free') && item.id.charCodeAt(0) % 3 === 0);
      });
    }
    
    // Apply price range filter
    filtered = filtered.filter(item => 
      item.price >= priceRange[0] && item.price <= priceRange[1]
    );
    
    setSearchResults(filtered);
  };

  const handleSuggestionClick = (suggestion: string) => {
    if (suggestion.startsWith('Category: ')) {
      setSearchTerm(suggestion.replace('Category: ', ''));
    } else if (suggestion.startsWith('Location: ')) {
      setSearchTerm(suggestion.replace('Location: ', ''));
    } else {
      setSearchTerm(suggestion);
    }
    setShowSuggestions(false);
  };

  const handleDietaryChange = (filter: string) => {
    setSelectedDietary(prev => 
      prev.includes(filter)
        ? prev.filter(item => item !== filter)
        : [...prev, filter]
    );
  };

  const clearFilters = () => {
    setSelectedDietary([]);
    setPriceRange([0, maxPrice]);
  };

  const activeFilterCount = selectedDietary.length + 
    (priceRange[0] > 0 || priceRange[1] < maxPrice ? 1 : 0);

  return (
    <Layout>
      <div className="max-w-screen-xl mx-auto px-4 py-6">
        <div className="relative mb-2">
          <div className="relative">
            <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input
              className="pl-10 bg-white shadow-sm border-gray-200 focus:border-primary focus:ring-primary"
              placeholder="Search for food by name or category..."
              type="search"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onFocus={() => setShowSuggestions(suggestions.length > 0)}
              onBlur={() => {
                // Delay hiding suggestions to allow for clicks
                setTimeout(() => setShowSuggestions(false), 200);
              }}
            />
            {searchTerm && (
              <button 
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-500"
                onClick={() => setSearchTerm('')}
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
          
          {showSuggestions && suggestions.length > 0 && (
            <div className="absolute z-10 w-full mt-1 bg-white shadow-lg rounded-md border border-gray-200">
              <ul className="py-1">
                {suggestions.map((suggestion, index) => (
                  <li 
                    key={index} 
                    className="px-3 py-2 hover:bg-gray-100 cursor-pointer text-sm"
                    onClick={() => handleSuggestionClick(suggestion)}
                  >
                    {suggestion}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
        
        <div className="flex justify-between items-center mb-4">
          <Button
            variant="outline"
            size="sm"
            className="flex items-center gap-2"
            onClick={() => setIsFilterOpen(!isFilterOpen)}
          >
            <Filter className="h-4 w-4" />
            <span>Filters</span>
            {activeFilterCount > 0 && (
              <span className="ml-1 bg-primary text-white text-xs rounded-full w-4 h-4 inline-flex items-center justify-center">
                {activeFilterCount}
              </span>
            )}
          </Button>
        </div>
        
        <Collapsible open={isFilterOpen} onOpenChange={setIsFilterOpen}>
          <CollapsibleContent>
            <FilterOptions 
              dietaryFilters={dietaryFilters}
              selectedDietary={selectedDietary}
              priceRange={priceRange}
              maxPrice={maxPrice}
              onDietaryChange={handleDietaryChange}
              onPriceChange={setPriceRange}
              onClearFilters={clearFilters}
            />
          </CollapsibleContent>
        </Collapsible>
        
        {(searchTerm || selectedDietary.length > 0 || priceRange[0] > 0 || priceRange[1] < maxPrice) && (
          <h2 className="text-xl font-medium mb-4">
            {searchResults.length 
              ? `Found ${searchResults.length} results`
              : `No results found`}
          </h2>
        )}
        
        {!searchTerm && selectedDietary.length === 0 && priceRange[0] === 0 && priceRange[1] === maxPrice && (
          <div className="text-center py-12">
            <div className="mx-auto w-16 h-16 mb-4 rounded-full bg-gray-100 flex items-center justify-center">
              <SearchIcon className="text-gray-400 w-8 h-8" />
            </div>
            <h3 className="text-lg font-medium text-gray-700 mb-2">Search for Food</h3>
            <p className="text-gray-500 max-w-md mx-auto">
              Type in the search box above to find your favorite dishes by name or category, or use filters to narrow down your options
            </p>
          </div>
        )}
        
        {isLoading && (searchTerm || selectedDietary.length > 0 || priceRange[0] > 0 || priceRange[1] < maxPrice) && (
          <div className="text-center py-8 text-gray-500">
            Searching...
          </div>
        )}
        
        {searchResults.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {searchResults.map((item) => (
              <FoodCard key={item.id} item={item} />
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
};

export default Search;
